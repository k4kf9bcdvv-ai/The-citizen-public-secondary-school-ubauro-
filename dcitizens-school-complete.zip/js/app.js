const state={role:"admin",view:"dashboard",search:"",date:new Date().toISOString().slice(0,10),classFilter:"All"};
const students=[
{id:"1001",name:"Ali Ahmed",class:"9-A",father:"Ahmed Khan",phone:"+92 300 0000001",present:true},
{id:"1002",name:"Ayesha Noor",class:"9-A",father:"Muhammad Noor",phone:"+92 300 0000002",present:true},
{id:"1003",name:"Hamza Ali",class:"8-B",father:"Aslam Ali",phone:"+92 300 0000003",present:false},
{id:"1004",name:"Maryam Bibi",class:"8-B",father:"Imran Bibi",phone:"+92 300 0000004",present:true},
{id:"1005",name:"Usman Raza",class:"10-A",father:"Raza Ahmed",phone:"+92 300 0000005",present:false},
{id:"1006",name:"Hira Fatima",class:"10-A",father:"Sajid Ahmed",phone:"+92 300 0000006",present:true}
];

function pct(){return Math.round(students.filter(s=>s.present).length/students.length*100)}
function nav(){return `<aside class="side">
<div class="brand"><div class="logo">DC</div><div><b>D Citizens</b><small>Public Secondary School</small></div></div>
<div class="campus">📍 Ubaro</div>
<nav>
${["dashboard","attendance","students","reports","notifications","settings"].map(v=>`<button class="${state.view===v?"active":""}" onclick="go('${v}')">${({dashboard:"⌂ Dashboard",attendance:"✓ Attendance",students:"👥 Students",reports:"▥ Reports",notifications:"◉ Parent Alerts",settings:"⚙ Settings"})[v]}</button>`).join("")}
</nav>
<div class="profile"><div class="avatar">A</div><div><b>Administrator</b><small>School Admin</small></div></div>
</aside>`}
function top(){return `<header><div><span class="muted">School Portal</span><h1>${({dashboard:"Dashboard",attendance:"Daily Attendance",students:"Students",reports:"Attendance Reports",notifications:"Parent Notifications",settings:"Settings"})[state.view]}</h1></div><div class="topright"><span class="date">📅 ${new Date().toLocaleDateString("en-PK",{day:"2-digit",month:"short",year:"numeric"})}</span><button class="outline" onclick="alert('Demo logout — connect Firebase Auth for production.')">Logout</button></div></header>`}
function dashboard(){
return `<section class="cards">
<div class="card blue"><span>Total Students</span><strong>${students.length}</strong><small>Across all classes</small></div>
<div class="card green"><span>Present Today</span><strong>${students.filter(s=>s.present).length}</strong><small>${pct()}% attendance</small></div>
<div class="card red"><span>Absent Today</span><strong>${students.filter(s=>!s.present).length}</strong><small>Parent alerts pending</small></div>
<div class="card purple"><span>Classes</span><strong>6</strong><small>Grades 5–10</small></div>
</section>
<div class="grid2">
<div class="panel"><div class="panelhead"><h2>Today’s Attendance</h2><button onclick="go('attendance')">Open register →</button></div>
<div class="progress"><div style="width:${pct()}%"></div></div><div class="bigpct">${pct()}%</div><p class="muted">Overall attendance for ${new Date().toLocaleDateString("en-PK")}</p>
<div class="legend"><span>● Present</span><span>● Absent</span></div></div>
<div class="panel"><div class="panelhead"><h2>Quick Actions</h2></div><div class="actions"><button onclick="go('attendance')">✓ Mark Attendance</button><button onclick="go('students')">＋ Add Student</button><button onclick="go('reports')">▥ View Reports</button><button onclick="go('notifications')">◉ Send Parent Alerts</button></div></div>
</div>
<div class="panel"><div class="panelhead"><h2>Recent Attendance</h2><button onclick="go('reports')">View all</button></div>${table(true)}</div>`}
function table(short=false){
let arr=students.filter(s=>(state.classFilter==="All"||s.class===state.classFilter)&&(!state.search||s.name.toLowerCase().includes(state.search.toLowerCase())||s.id.includes(state.search)));
return `<div class="tablewrap"><table><thead><tr><th>GR No.</th><th>Student</th><th>Class</th><th>Father / Guardian</th><th>Phone</th><th>Status</th>${short?"":"Action"}</tr></thead><tbody>${arr.map(s=>`<tr><td>${s.id}</td><td><div class="student"><div class="mini">${s.name[0]}</div><b>${s.name}</b></div></td><td>${s.class}</td><td>${s.father}</td><td>${s.phone}</td><td><span class="pill ${s.present?"ok":"bad"}">${s.present?"Present":"Absent"}</span></td>${short?"":`<td><button class="small" onclick="toggle('${s.id}')">${s.present?"Mark absent":"Mark present"}</button></td>`}</tr>`).join("")}</tbody></table></div>`}
function attendance(){return `<div class="toolbar"><input type="date" value="${state.date}" onchange="state.date=this.value;render()"><select onchange="state.classFilter=this.value;render()"><option>All</option>${[...new Set(students.map(s=>s.class))].map(c=>`<option ${state.classFilter===c?"selected":""}>${c}</option>`).join("")}</select><input placeholder="Search name / GR number" value="${state.search}" oninput="state.search=this.value;render()"><button class="primary" onclick="capture()">📷 Take Live Photo</button></div><div class="panel"><div class="panelhead"><div><h2>Attendance Register</h2><p class="muted">Mark students present/absent and capture a live photo where required.</p></div><button class="primary" onclick="saveAttendance()">Save Attendance</button></div>${table()}</div>`}
function studentsPage(){return `<div class="toolbar"><input placeholder="Search students..." oninput="state.search=this.value;render()"><button class="primary" onclick="addStudent()">＋ Add Student</button></div><div class="panel">${table()}</div>`}
function reports(){return `<div class="cards"><div class="card blue"><span>Today</span><strong>${pct()}%</strong><small>Attendance</small></div><div class="card green"><span>This Month</span><strong>91%</strong><small>Sample calculation</small></div><div class="card purple"><span>This Year</span><strong>94%</strong><small>Sample calculation</small></div></div><div class="panel"><div class="panelhead"><h2>Monthly & Yearly Reports</h2><button class="primary" onclick="downloadCSV()">Download CSV</button></div><table><thead><tr><th>Student</th><th>GR No.</th><th>Class</th><th>Monthly %</th><th>Yearly %</th></tr></thead><tbody>${students.map((s,i)=>`<tr><td>${s.name}</td><td>${s.id}</td><td>${s.class}</td><td>${[88,96,79,94,86,91][i]}%</td><td>${[92,95,82,96,89,93][i]}%</td></tr>`).join("")}</tbody></table></div>`}
function notifications(){return `<div class="grid2"><div class="panel"><h2>Parent Alerts</h2><p class="muted">After attendance is saved, absent students can be sent an SMS or WhatsApp alert.</p>${students.filter(s=>!s.present).map(s=>`<div class="alertrow"><div><b>${s.name}</b><small>GR ${s.id} · ${s.phone}</small></div><button class="small" onclick="sendAlert('${s.id}')">Send Alert</button></div>`).join("")}</div><div class="panel"><h2>Message Preview</h2><div class="message">Assalam-o-Alaikum. This is to inform you that <b>[Student Name]</b> (GR No. [GR]) was marked <b>ABSENT</b> today at D Citizens Public Secondary School, Ubaro. Please contact the school office if needed.</div><p class="muted">Use an approved SMS provider or WhatsApp Business Cloud API. Credentials must stay on a secure backend.</p></div></div>`}
function settings(){return `<div class="panel form"><h2>School Settings</h2><label>School Name<input value="D Citizens Public Secondary School"></label><label>Campus<input value="Ubaro"></label><label>Admin Email<input placeholder="admin@your-school-domain.com"></label><label>Notification Mode<select><option>SMS + WhatsApp</option><option>SMS only</option><option>WhatsApp only</option></select></label><button class="primary" onclick="alert('Settings saved in demo. Connect Firestore for permanent storage.')">Save Settings</button></div>`}
function render(){document.getElementById("app").innerHTML=`<div class="layout">${nav()}<main>${top()}${state.view==="dashboard"?dashboard():state.view==="attendance"?attendance():state.view==="students"?studentsPage():state.view==="reports"?reports():state.view==="notifications"?notifications():settings()}</main></div>`}
function go(v){state.view=v;state.search="";render()}
function toggle(id){let s=students.find(x=>x.id===id);s.present=!s.present;render()}
function saveAttendance(){alert("Attendance saved in demo. In production this writes to Firestore and triggers secure parent notification jobs.");}
function capture(){if(!navigator.mediaDevices){alert("Camera is not available in this browser.");return} navigator.mediaDevices.getUserMedia({video:true}).then(stream=>{alert("Camera permission granted. Production version should show the camera preview and securely upload the captured image.");stream.getTracks().forEach(t=>t.stop())}).catch(()=>alert("Camera permission was not granted."))}
function addStudent(){let n=prompt("Student name"); if(n){students.push({id:String(1000+students.length+1),name:n,class:"9-A",father:"",phone:"",present:true});render()}}
function sendAlert(id){let s=students.find(x=>x.id===id);alert(`Demo alert queued for ${s.father || "parent"} at ${s.phone}. Connect SMS/WhatsApp provider to send it for real.`)}
function downloadCSV(){let rows=[["GR No.","Name","Class","Status"],...students.map(s=>[s.id,s.name,s.class,s.present?"Present":"Absent"])];let blob=new Blob([rows.map(r=>r.join(",")).join("\\n")],{type:"text/csv"});let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="attendance-report.csv";a.click()}
render();
