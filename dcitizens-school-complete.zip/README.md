# D Citizens Public Secondary School — Complete School Portal

A beautiful responsive school attendance portal starter with:
- Admin dashboard
- Teacher dashboard
- Student roster and attendance
- Camera/photo capture UI
- Monthly/yearly attendance calculations
- Parent SMS/WhatsApp notification settings
- Firebase-ready architecture

## Demo
Open `index.html` in a browser.

## Production setup
1. Create a Firebase project.
2. Enable Authentication, Firestore and Storage.
3. Add your Firebase web configuration to `js/config.js`.
4. Add an SMS provider (e.g. Twilio) or WhatsApp Business Cloud API through a secure backend/Cloud Function.
5. Never put provider secret keys in frontend JavaScript.
6. Deploy the `public/` contents to Firebase Hosting.

This package is a frontend/prototype and does not send real SMS/WhatsApp messages until a provider/backend is configured.
