# D Citizens Public Secondary School — Online Attendance

A mobile-friendly school attendance starter with:
- School email/password login (Firebase Authentication)
- Student GR number, name, class, father/guardian and phone
- Student photo upload from phone camera
- Daily Present/Absent attendance
- Attendance photo capture/upload per student
- Daily dashboard
- Monthly attendance percentage and CSV export
- Firebase Firestore database + Storage

## Important: parent messages
Automatic SMS/WhatsApp messages are intentionally not hard-coded because they require a messaging provider and the school's consent/credentials. A provider such as Twilio or Meta WhatsApp Cloud API can be connected to a backend/Cloud Function. The app should send a message only after attendance is saved and should log message status.

## Setup
1. Create a Firebase project at https://console.firebase.google.com/.
2. Enable Authentication → Email/Password.
3. Create Firestore Database.
4. Enable Storage.
5. Register a Web App and copy its Firebase config into `js/app.js`, replacing the `PASTE_...` values.
6. Create the school's staff email account in Firebase Authentication.
7. Add Firestore/Storage security rules so only authorized school staff can read/write records.
8. Test on a phone over HTTPS. For free hosting, Firebase Hosting can be used; Google account/project setup is required.

## Recommended production additions
- Admin/staff roles (principal, teacher, attendance operator)
- Audit log for edits
- Duplicate GR-number protection
- Class/section management
- Late status
- Parent consent/privacy policy for student photos
- Server-side SMS/WhatsApp notification function
- Backup/export and restore
- Strong Firestore security rules

This package is a functional starter/prototype; publishing it publicly and sending real parent messages requires configuring the school's own accounts and credentials.
